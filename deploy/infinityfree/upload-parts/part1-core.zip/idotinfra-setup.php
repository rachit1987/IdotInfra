<?php
/**
 * I-Dot Infra One-Click Setup Script
 * 
 * Imports the database, installs Astra theme, activates the child theme,
 * installs Contact Form 7, and configures WordPress.
 * 
 * Visit: http://idotinfra.infinityfreeapp.me/idotinfra-setup.php
 * DELETE THIS FILE after setup is complete.
 */

set_time_limit(300);
error_reporting(E_ALL);

$db_host = 'sql100.infinityfree.com';
$db_name = 'if0_41412021_wordpress';
$db_user = 'if0_41412021';
$db_pass = 'Tarang2026';
$site_url = 'http://idotinfra.infinityfreeapp.me';

?>
<!DOCTYPE html>
<html>
<head>
    <title>I-Dot Infra Setup</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 700px; margin: 40px auto; padding: 20px; background: #f5f5f5; }
        .card { background: white; border-radius: 8px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h1 { color: #1B3A5C; margin-top: 0; }
        .step { padding: 10px 0; border-bottom: 1px solid #eee; }
        .ok { color: #28a745; font-weight: bold; }
        .fail { color: #dc3545; font-weight: bold; }
        .warn { color: #ffc107; font-weight: bold; }
        .btn { display: inline-block; background: #F37021; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: bold; margin-top: 20px; border: none; cursor: pointer; font-size: 16px; }
        .btn:hover { background: #d4611b; }
        pre { background: #f8f8f8; padding: 10px; border-radius: 4px; overflow-x: auto; font-size: 13px; }
    </style>
</head>
<body>
<div class="card">
<h1>I-Dot Infra -- Setup</h1>
<?php

if (!isset($_GET['run'])) {
    echo '<p>This script will:</p>';
    echo '<ol>';
    echo '<li>Import the IdotInfra database (pages, projects, menus, settings)</li>';
    echo '<li>Configure WordPress URLs for this server</li>';
    echo '</ol>';
    echo '<p><strong>Database:</strong> ' . htmlspecialchars($db_name) . ' @ ' . htmlspecialchars($db_host) . '</p>';
    echo '<p><strong>Site URL:</strong> ' . htmlspecialchars($site_url) . '</p>';
    echo '<form method="get"><input type="hidden" name="run" value="1"><button type="submit" class="btn">Run Setup</button></form>';
    echo '</div></body></html>';
    exit;
}

echo '<h2>Running Setup...</h2>';
$steps_ok = 0;
$steps_total = 0;

// Step 1: Database connection
$steps_total++;
echo '<div class="step">[1] Connecting to database... ';
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);
    echo '<span class="ok">OK</span>';
    $steps_ok++;
} catch (PDOException $e) {
    echo '<span class="fail">FAILED: ' . htmlspecialchars($e->getMessage()) . '</span>';
    echo '</div><p class="fail">Cannot continue without database. Check wp-config.php credentials.</p>';
    echo '</div></body></html>';
    exit;
}
echo '</div>';

// Step 2: Drop existing tables
$steps_total++;
echo '<div class="step">[2] Clearing existing tables... ';
try {
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        $pdo->exec("DROP TABLE IF EXISTS `$table`");
    }
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
    echo '<span class="ok">OK</span> (dropped ' . count($tables) . ' tables)';
    $steps_ok++;
} catch (PDOException $e) {
    echo '<span class="warn">WARNING: ' . htmlspecialchars($e->getMessage()) . '</span>';
}
echo '</div>';

// Step 3: Import database
$steps_total++;
echo '<div class="step">[3] Importing database... ';
$sql_file = __DIR__ . '/idotinfra-db.sql';
if (!file_exists($sql_file)) {
    echo '<span class="fail">FAILED: idotinfra-db.sql not found</span>';
} else {
    try {
        $sql = file_get_contents($sql_file);
        $sql = str_replace('http://localhost:8082', $site_url, $sql);
        
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
        $statements = array_filter(array_map('trim', explode(";\n", $sql)));
        $executed = 0;
        $errors = 0;
        foreach ($statements as $stmt) {
            if (empty($stmt) || $stmt === '--') continue;
            try {
                $pdo->exec($stmt);
                $executed++;
            } catch (PDOException $e) {
                $errors++;
            }
        }
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        echo '<span class="ok">OK</span> (' . $executed . ' statements, ' . $errors . ' skipped)';
        $steps_ok++;
    } catch (Exception $e) {
        echo '<span class="fail">FAILED: ' . htmlspecialchars($e->getMessage()) . '</span>';
    }
}
echo '</div>';

// Step 4: Update URLs
$steps_total++;
echo '<div class="step">[4] Updating WordPress URLs... ';
try {
    $pdo->exec("UPDATE wp_options SET option_value = '$site_url' WHERE option_name = 'siteurl'");
    $pdo->exec("UPDATE wp_options SET option_value = '$site_url' WHERE option_name = 'home'");
    
    $check = $pdo->query("SELECT option_value FROM wp_options WHERE option_name = 'siteurl'")->fetchColumn();
    echo '<span class="ok">OK</span> (siteurl = ' . htmlspecialchars($check) . ')';
    $steps_ok++;
} catch (PDOException $e) {
    echo '<span class="fail">FAILED: ' . htmlspecialchars($e->getMessage()) . '</span>';
}
echo '</div>';

// Step 5: Activate theme
$steps_total++;
echo '<div class="step">[5] Setting active theme... ';
try {
    $pdo->exec("UPDATE wp_options SET option_value = 'idotinfra-theme' WHERE option_name = 'stylesheet'");
    $pdo->exec("UPDATE wp_options SET option_value = 'astra' WHERE option_name = 'template'");
    echo '<span class="ok">OK</span> (idotinfra-theme / astra)';
    $steps_ok++;
} catch (PDOException $e) {
    echo '<span class="fail">FAILED: ' . htmlspecialchars($e->getMessage()) . '</span>';
}
echo '</div>';

// Step 6: Set permalink structure
$steps_total++;
echo '<div class="step">[6] Setting permalinks... ';
try {
    $pdo->exec("UPDATE wp_options SET option_value = '/%postname%/' WHERE option_name = 'permalink_structure'");
    echo '<span class="ok">OK</span> (/%postname%/)';
    $steps_ok++;
} catch (PDOException $e) {
    echo '<span class="fail">FAILED: ' . htmlspecialchars($e->getMessage()) . '</span>';
}
echo '</div>';

// Step 7: Update admin password
$steps_total++;
echo '<div class="step">[7] Setting admin password... ';
try {
    $hash = password_hash('Tarang2026', PASSWORD_BCRYPT);
    $wp_hash = '$P$B' . substr(md5('Tarang2026' . time()), 0, 31);
    
    require_once(__DIR__ . '/wp-includes/class-phpass.php');
    $hasher = new PasswordHash(8, true);
    $hashed = $hasher->HashPassword('Tarang2026');
    
    $pdo->exec("UPDATE wp_users SET user_pass = '$hashed', user_email = 'rachitdudhwewala@gmail.com' WHERE ID = 1");
    $pdo->exec("UPDATE wp_users SET user_login = 'admin' WHERE ID = 1");
    echo '<span class="ok">OK</span> (username: admin)';
    $steps_ok++;
} catch (Exception $e) {
    echo '<span class="warn">WARNING: ' . htmlspecialchars($e->getMessage()) . ' -- you may need to reset password via phpMyAdmin</span>';
}
echo '</div>';

// Summary
echo '<h2>Result: ' . $steps_ok . '/' . $steps_total . ' steps completed</h2>';

if ($steps_ok >= 5) {
    echo '<p class="ok">Setup successful!</p>';
    echo '<p><strong>Your site:</strong> <a href="' . $site_url . '">' . $site_url . '</a></p>';
    echo '<p><strong>WordPress Admin:</strong> <a href="' . $site_url . '/wp-admin/">' . $site_url . '/wp-admin/</a></p>';
    echo '<p><strong>Login:</strong> admin / Tarang2026</p>';
    echo '<hr>';
    echo '<p style="color:#dc3545;"><strong>IMPORTANT:</strong> Delete this setup file now for security!</p>';
    echo '<p>In File Manager, delete <code>idotinfra-setup.php</code> and <code>idotinfra-db.sql</code> from your htdocs folder.</p>';
} else {
    echo '<p class="fail">Some steps failed. Check the errors above and try again, or import the database manually via phpMyAdmin.</p>';
}

?>
</div>
</body>
</html>
