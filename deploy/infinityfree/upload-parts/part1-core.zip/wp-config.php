<?php
/**
 * WordPress Configuration for InfinityFree - I-Dot Infra
 */

define( 'DB_NAME', 'if0_41412021_wordpress' );
define( 'DB_USER', 'if0_41412021' );
define( 'DB_PASSWORD', 'Tarang2026' );
define( 'DB_HOST', 'sql100.infinityfree.com' );
define( 'DB_CHARSET', 'utf8mb4' );
define( 'DB_COLLATE', '' );

define('AUTH_KEY',         'G=-nWN_UzoWP5dRP02@g/eOv=)OD~^%+=C}FkG1@>1UHox?W~6KP*-{Z/)mvr&ZV');
define('SECURE_AUTH_KEY',  ',6{s$|lcoYG S1WU*{R|h-Ds&NLMd-$=Q9<wm|IEh:AYHPegfU+2OlVd;i`Z!r8>');
define('LOGGED_IN_KEY',    'N^-~/bcU7A#aT:I.p[PFa,@1!#nF)d$VM.-A9j8r>A1TGIZePBv@q%NTX5[jnDxE');
define('NONCE_KEY',        'LV.zs8<62|;WMBfkTKep&34#Q+l>9K=kb$p$rL@6leTP4GR<fjl+Gm%L0+wuhV:3');
define('AUTH_SALT',        'wuMr9{q={wJ>VRR!:L],EE/^+x@2[2|v9[yW)?LdIaAZ~[z|r+KX)}6^(IyR8sDp');
define('SECURE_AUTH_SALT', 'o-9|aC=KbGhLw.qy$uK%vjjnqyYNExpge|:es*xSNE^r=%f^z.UU4L,-i:($!NI:');
define('LOGGED_IN_SALT',   'Fbp G:&O%+9}eiejw<TGmBJ_d.)j87i88H+5f(BAp?As6-*Cu+Tke2cl[I?F91mc');
define('NONCE_SALT',       'r{<CU=P)Nl[uR0t-o(/c]hw)RAN]gx[`o4k>JC&Vfl0Td]?L>@b!Am-;5WYDW@|8');

$table_prefix = 'wp_';

define( 'WP_DEBUG', false );

if ( ! defined( 'ABSPATH' ) ) {
    define( 'ABSPATH', __DIR__ . '/' );
}

require_once ABSPATH . 'wp-settings.php';
